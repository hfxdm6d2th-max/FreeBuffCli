// public/app.js
//
// Connects to the backend websocket, renders the REAL freebuff pty
// output into an xterm.js terminal (unmodified — same bytes, same
// colors, same cursor control), and forwards typed input as stdin.
// Also watches for a "login_prompt" event from the server to show a
// distinct login step, pulled directly from the CLI's real output.

(() => {
  const statusDot = document.getElementById("status-dot");
  const statusText = document.getElementById("status-text");
  const loginPanel = document.getElementById("login-panel");
  const loginLinks = document.getElementById("login-links");
  const loginCodes = document.getElementById("login-codes");
  const loginRawText = document.getElementById("login-raw-text");
  const input = document.getElementById("input");
  const sendBtn = document.getElementById("send-btn");
  const termWrap = document.getElementById("term-wrap");

  // --- xterm.js setup: this renders the raw terminal stream faithfully ---
  const term = new Terminal({
    convertEol: true,
    fontSize: 14,
    fontFamily: '"SF Mono", Menlo, Consolas, "Liberation Mono", monospace',
    theme: {
      background: "#010409",
      foreground: "#e6edf3",
      cursor: "#58a6ff",
    },
    scrollback: 5000,
  });
  const fitAddon = new FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.open(document.getElementById("terminal"));
  fitAddon.fit();

  function fitAndNotify() {
    try {
      fitAddon.fit();
      const { cols, rows } = term;
      sendJSON({ type: "resize", cols, rows });
    } catch {
      /* ignore transient resize errors */
    }
  }
  window.addEventListener("resize", fitAndNotify);

  // --- websocket ---
  // The token can be supplied via ?token=... in the page URL (simplest for
  // a personal deployment) or typed once and cached in sessionStorage so
  // it isn't retyped on every reload. It is never hardcoded here.
  function getToken() {
    const fromQuery = new URLSearchParams(location.search).get("token");
    if (fromQuery) {
      sessionStorage.setItem("freebuff_token", fromQuery);
      // Strip it from the visible URL so it isn't left in browser history.
      const cleanUrl = location.pathname;
      history.replaceState({}, "", cleanUrl);
      return fromQuery;
    }
    const cached = sessionStorage.getItem("freebuff_token");
    if (cached) return cached;
    return window.prompt("Enter access token:") || "";
  }

  const token = getToken();
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(
    `${proto}://${location.host}/ws?token=${encodeURIComponent(token)}`
  );
  let loggedIn = false;

  function setStatus(cls, text) {
    statusDot.className = `dot ${cls}`;
    statusText.textContent = text;
  }

  function sendJSON(obj) {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
  }

  setStatus("connecting", "connecting…");

  ws.addEventListener("open", () => {
    setStatus("connecting", "starting freebuff…");
    fitAndNotify();
  });

  ws.addEventListener("close", (event) => {
    if (event.code === 1008 || event.code === 4001) {
      setStatus("error", "unauthorized — check token");
      sessionStorage.removeItem("freebuff_token");
    } else {
      setStatus("error", "disconnected");
    }
    input.disabled = true;
    sendBtn.disabled = true;
  });

  ws.addEventListener("error", () => {
    setStatus("error", "connection error");
  });

  ws.addEventListener("message", (event) => {
    let msg;
    try {
      msg = JSON.parse(event.data);
    } catch {
      // Fallback: treat as raw text
      term.write(event.data);
      return;
    }

    switch (msg.type) {
      case "data":
        // Raw bytes from the real freebuff process, written unmodified.
        term.write(msg.data);
        if (!loggedIn) {
          setStatus("connected", "freebuff running");
        }
        break;

      case "login_prompt":
        showLoginStep(msg);
        break;

      case "spawn_error":
        setStatus("error", "failed to start");
        term.write(`\r\n\x1b[31m${msg.message}\x1b[0m\r\n`);
        break;

      case "exit":
        setStatus("error", `process exited (${msg.exitCode ?? msg.signal})`);
        break;

      case "idle_timeout":
        setStatus("error", "session closed (idle timeout)");
        term.write("\r\n\x1b[33mSession closed due to inactivity.\x1b[0m\r\n");
        break;

      case "backpressure_exceeded":
        setStatus("error", "session closed (too much unread output)");
        term.write(
          "\r\n\x1b[33mConnection closed: output was queuing faster than it could be delivered.\x1b[0m\r\n"
        );
        break;

      default:
        break;
    }
  });

  function showLoginStep(msg) {
    loginPanel.classList.remove("hidden");
    setStatus("connecting", "waiting for sign-in…");

    loginLinks.innerHTML = "";
    (msg.urls || []).forEach((url) => {
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = url;
      loginLinks.appendChild(a);
    });

    loginCodes.innerHTML = "";
    (msg.codes || []).forEach((code) => {
      const span = document.createElement("span");
      span.className = "code-chip";
      span.textContent = code;
      loginCodes.appendChild(span);
    });

    loginRawText.textContent = msg.raw || "";
  }

  // The login panel is an overlay, not a separate flow: the real
  // terminal underneath keeps receiving output the whole time. Once
  // the CLI's own output shows the user is past auth (any further
  // normal output arrives), we just let them dismiss it manually,
  // since only the CLI itself truly knows when auth completed.
  loginPanel.addEventListener("click", (e) => {
    if (e.target === loginPanel) {
      loginPanel.classList.add("hidden");
      loggedIn = true;
      setStatus("connected", "freebuff running");
    }
  });

  const dismissHint = document.createElement("button");
  dismissHint.textContent = "I've signed in — continue";
  dismissHint.style.cssText =
    "margin-top:14px;width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:transparent;color:var(--text);font-size:13px;cursor:pointer;";
  dismissHint.addEventListener("click", () => {
    loginPanel.classList.add("hidden");
    loggedIn = true;
    setStatus("connected", "freebuff running");
    input.focus();
  });
  document.querySelector(".login-card").appendChild(dismissHint);

  // --- composer: send typed messages as real stdin to the CLI ---
  function autoGrow() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 140) + "px";
  }
  input.addEventListener("input", autoGrow);

  function sendCurrentInput() {
    const text = input.value;
    if (!text) return;
    // Send exactly what was typed, plus Enter — this goes straight to
    // the freebuff process's stdin via the pty, same as a real terminal.
    sendJSON({ type: "input", data: text + "\r" });
    input.value = "";
    autoGrow();
  }

  sendBtn.addEventListener("click", sendCurrentInput);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendCurrentInput();
    }
  });

  // Let the terminal itself also receive raw key input if the user
  // taps into it directly (for control sequences like Ctrl+C, arrow
  // keys navigating CLI menus, etc.) — this keeps it a *real* terminal,
  // not just a message box bolted on top.
  term.onData((data) => {
    sendJSON({ type: "input", data });
  });

  termWrap.addEventListener("click", () => term.focus());
})();
