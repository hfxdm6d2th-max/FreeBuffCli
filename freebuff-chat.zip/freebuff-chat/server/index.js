// server/index.js
//
// Spawns the REAL `freebuff` CLI inside a pseudo-terminal (node-pty) and
// streams every byte of stdout/stderr to the browser over a websocket,
// and forwards every byte typed in the browser back to the CLI's stdin.
//
// This is a real terminal session. Nothing about freebuff's output or
// behavior is simulated, mocked, or rewritten — the server only *watches*
// the byte stream to detect a login/device-code prompt so the frontend
// can surface it as a distinct UI step. The raw bytes are still sent
// through unmodified either way.
//
// SECURITY: this file requires an auth token on every WebSocket upgrade
// and validates Origin. See README "Security" section for setup.

const express = require("express");
const http = require("http");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const pty = require("node-pty");
const { WebSocketServer } = require("ws");

const PORT = process.env.PORT || 8787;

// The real command. Override via env if `freebuff` isn't on PATH
// (e.g. FREEBUFF_CMD="node /path/to/freebuff/cli.js").
const FREEBUFF_CMD = process.env.FREEBUFF_CMD || "freebuff";

// FREEBUFF_ARGS as a JSON array string, e.g. '["--flag","value with spaces"]'
// (a plain space-split string can't represent quoted/spaced args correctly).
let FREEBUFF_ARGS = [];
if (process.env.FREEBUFF_ARGS) {
  try {
    const parsed = JSON.parse(process.env.FREEBUFF_ARGS);
    if (Array.isArray(parsed) && parsed.every((a) => typeof a === "string")) {
      FREEBUFF_ARGS = parsed;
    } else {
      console.warn("FREEBUFF_ARGS must be a JSON array of strings; ignoring.");
    }
  } catch {
    console.warn(
      "FREEBUFF_ARGS is not valid JSON (expected e.g. '[\"--flag\"]'); ignoring."
    );
  }
}

// --- Auth ---------------------------------------------------------------
// Require AUTH_TOKEN to be set. Clients must connect to /ws?token=...
// with a token that matches, using a constant-time comparison.
const AUTH_TOKEN = process.env.AUTH_TOKEN || "";
if (!AUTH_TOKEN) {
  console.error(
    "FATAL: AUTH_TOKEN is not set. Refusing to start without an access " +
      "token, since this app spawns a live shell-like process. Set " +
      "AUTH_TOKEN as an environment variable / Replit Secret and restart."
  );
  process.exit(1);
}

function timingSafeEqual(a, b) {
  const bufA = Buffer.from(String(a));
  const bufB = Buffer.from(String(b));
  if (bufA.length !== bufB.length) {
    // Still do a comparison of equal-length buffers to avoid a timing
    // signal purely from length checks being visibly fast.
    crypto.timingSafeEqual(bufA, Buffer.alloc(bufA.length));
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

// --- Origin allowlist -----------------------------------------------------
// Comma-separated list of allowed origins, e.g.
// ALLOWED_ORIGINS="https://myrepl.repl.co,http://localhost:8787"
// If unset, falls back to allowing only same-origin requests inferred from
// the Host header (safe default for a single-deployment app).
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

function isOriginAllowed(origin, host) {
  if (!origin) {
    // No Origin header (e.g. non-browser client, curl) — allow, since
    // browsers always send Origin for cross-origin and same-origin
    // WebSocket upgrades; this only affects non-browser callers who
    // still need the token to do anything.
    return true;
  }
  if (ALLOWED_ORIGINS.length > 0) {
    return ALLOWED_ORIGINS.includes(origin);
  }
  // Default: derive allowed origin from the request's own Host header.
  try {
    const originHost = new URL(origin).host;
    return originHost === host;
  } catch {
    return false;
  }
}

// --- Environment allowlist for the spawned CLI -----------------------------
// Only pass through what freebuff plausibly needs, not the whole server
// environment (which may hold unrelated secrets for this deployment).
const ENV_ALLOWLIST = [
  "PATH",
  "HOME",
  "USER",
  "LANG",
  "LC_ALL",
  "TERM",
  "SHELL",
  "TMPDIR",
  "NODE_ENV",
];
// Also allow anything explicitly prefixed FREEBUFF_ENV_ so operators can
// pass extra vars the CLI needs without exposing the whole environment.
function buildChildEnv() {
  const env = {};
  for (const key of ENV_ALLOWLIST) {
    if (process.env[key] !== undefined) env[key] = process.env[key];
  }
  for (const key of Object.keys(process.env)) {
    if (key.startsWith("FREEBUFF_ENV_")) {
      env[key.slice("FREEBUFF_ENV_".length)] = process.env[key];
    }
  }
  env.TERM = env.TERM || "xterm-256color";
  return env;
}

// --- Connection limits ------------------------------------------------------
const MAX_CONNECTIONS = parseInt(process.env.MAX_CONNECTIONS || "5", 10);
const IDLE_TIMEOUT_MS = parseInt(
  process.env.IDLE_TIMEOUT_MS || String(30 * 60 * 1000),
  10
); // 30 min default
const MAX_INPUT_LEN = 8192; // per-message stdin cap
const MAX_BUFFERED_AMOUNT = 4 * 1024 * 1024; // 4MB of unsent output before we cut the session
let activeConnections = 0;

const app = express();
app.use(express.static(path.join(__dirname, "..", "public")));

const server = http.createServer(app);
const wss = new WebSocketServer({
  noServer: true,
  // Hard cap slightly above MAX_INPUT_LEN so oversized frames are
  // rejected by the library itself, before any application-level
  // parsing or the 8KB stdin check runs.
  maxPayload: 16 * 1024,
});

// Regexes used ONLY to detect that a login step is happening, so the
// frontend can show a "Login" banner with the link/code pulled out of
// the real CLI output. We never generate or alter the text ourselves.
const LOGIN_HINT_RE =
  /(sign in|log ?in|authenticate|device code|verification code|visit|open (this|the following) (link|url)|activate)/i;
const URL_RE = /(https?:\/\/[^\s]+)/g;
const CODE_RE = /\b([A-Z0-9]{4,}-[A-Z0-9]{4,}|[A-Z0-9]{6,8})\b/g;

function safeSend(ws, obj) {
  if (ws.readyState === ws.OPEN) {
    try {
      ws.send(JSON.stringify(obj));
    } catch (err) {
      console.error("[ws] send failed:", err.message);
    }
  }
}

// --- Manual upgrade handling so we can check auth + origin before the
//     WebSocketServer completes the handshake ---
server.on("upgrade", (req, socket, head) => {
  let url;
  try {
    url = new URL(req.url, `http://${req.headers.host}`);
  } catch {
    socket.destroy();
    return;
  }

  if (url.pathname !== "/ws") {
    socket.destroy();
    return;
  }

  const origin = req.headers.origin;
  if (!isOriginAllowed(origin, req.headers.host)) {
    console.warn(`[ws] rejected connection: bad origin "${origin}"`);
    socket.write("HTTP/1.1 403 Forbidden\r\n\r\n");
    socket.destroy();
    return;
  }

  const token = url.searchParams.get("token");
  if (!token || !timingSafeEqual(token, AUTH_TOKEN)) {
    console.warn("[ws] rejected connection: bad or missing token");
    socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
    socket.destroy();
    return;
  }

  if (activeConnections >= MAX_CONNECTIONS) {
    console.warn("[ws] rejected connection: at MAX_CONNECTIONS");
    socket.write("HTTP/1.1 503 Service Unavailable\r\n\r\n");
    socket.destroy();
    return;
  }

  wss.handleUpgrade(req, socket, head, (ws) => {
    wss.emit("connection", ws, req);
  });
});

wss.on("connection", (ws) => {
  activeConnections++;
  console.log(
    `[ws] client connected (${activeConnections}/${MAX_CONNECTIONS}), spawning freebuff...`
  );

  let ptyProcess;
  try {
    ptyProcess = pty.spawn(FREEBUFF_CMD, FREEBUFF_ARGS, {
      name: "xterm-256color",
      cols: 80,
      rows: 30,
      cwd: process.env.FREEBUFF_CWD || os.homedir(),
      env: buildChildEnv(),
    });
  } catch (err) {
    safeSend(ws, {
      type: "spawn_error",
      message:
        `Failed to start "${FREEBUFF_CMD}": ${err.message}. ` +
        `Make sure it's installed (npm install -g freebuff) and on PATH, ` +
        `or set FREEBUFF_CMD to its full path.`,
    });
    ws.close();
    activeConnections--;
    return;
  }

  let scanBuffer = "";
  const SCAN_BUFFER_MAX = 4000;
  let closed = false;

  let idleTimer = null;
  function resetIdleTimer() {
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      console.log("[ws] idle timeout reached, closing connection");
      safeSend(ws, { type: "idle_timeout" });
      cleanup();
    }, IDLE_TIMEOUT_MS);
  }
  resetIdleTimer();

  function cleanup() {
    if (closed) return;
    closed = true;
    if (idleTimer) clearTimeout(idleTimer);
    try {
      ptyProcess.kill();
    } catch {
      // already dead
    }
    try {
      ws.close();
    } catch {
      // already closed
    }
    activeConnections = Math.max(0, activeConnections - 1);
  }

  ptyProcess.onData((data) => {
    // Output backpressure: if the client can't keep up and the socket's
    // send buffer grows past a threshold, stop pushing more and close
    // the session rather than letting memory grow unbounded. The pty is
    // paused for the same reason — no point buffering CLI output for a
    // client that isn't draining it.
    if (ws.bufferedAmount > MAX_BUFFERED_AMOUNT) {
      console.warn(
        `[ws] output backpressure exceeded (${ws.bufferedAmount} bytes queued), closing session`
      );
      safeSend(ws, { type: "backpressure_exceeded" });
      cleanup();
      return;
    }

    safeSend(ws, { type: "data", data });

    scanBuffer = (scanBuffer + data).slice(-SCAN_BUFFER_MAX);
    if (LOGIN_HINT_RE.test(scanBuffer)) {
      const urls = [...scanBuffer.matchAll(URL_RE)].map((m) => m[0]);
      const codes = [...scanBuffer.matchAll(CODE_RE)].map((m) => m[0]);
      if (urls.length || codes.length) {
        safeSend(ws, {
          type: "login_prompt",
          urls: [...new Set(urls)],
          codes: [...new Set(codes)],
          raw: scanBuffer,
        });
      }
    }
  });

  ptyProcess.onExit(({ exitCode, signal }) => {
    safeSend(ws, { type: "exit", exitCode, signal });
    cleanup();
  });

  ws.on("message", (msg) => {
    resetIdleTimer();

    let parsed;
    try {
      parsed = JSON.parse(msg.toString());
    } catch {
      return; // ignore non-JSON frames; raw stdin must go through {type:"input"}
    }

    if (!parsed || typeof parsed.type !== "string") return;

    switch (parsed.type) {
      case "input": {
        if (typeof parsed.data !== "string") {
          console.warn("[ws] ignored input: data was not a string");
          return;
        }
        if (parsed.data.length > MAX_INPUT_LEN) {
          console.warn("[ws] ignored input: exceeded MAX_INPUT_LEN");
          return;
        }
        try {
          ptyProcess.write(parsed.data);
        } catch (err) {
          console.error("[pty] write failed:", err.message);
        }
        break;
      }
      case "resize": {
        const cols = Number(parsed.cols);
        const rows = Number(parsed.rows);
        if (
          Number.isInteger(cols) &&
          Number.isInteger(rows) &&
          cols > 0 &&
          cols <= 500 &&
          rows > 0 &&
          rows <= 500
        ) {
          try {
            ptyProcess.resize(cols, rows);
          } catch (err) {
            console.error("[pty] resize failed:", err.message);
          }
        }
        break;
      }
      default:
        break;
    }
  });

  ws.on("close", () => {
    console.log("[ws] client disconnected, killing freebuff process");
    cleanup();
  });

  ws.on("error", (err) => {
    console.error("[ws] error:", err.message);
    cleanup();
  });
});

server.listen(PORT, () => {
  console.log(`freebuff-chat listening on http://localhost:${PORT}`);
  console.log(`Spawning command: ${FREEBUFF_CMD} ${FREEBUFF_ARGS.join(" ")}`);
  console.log(
    `Max concurrent connections: ${MAX_CONNECTIONS}, idle timeout: ${IDLE_TIMEOUT_MS}ms`
  );
});
