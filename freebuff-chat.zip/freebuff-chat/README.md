# freebuff-chat

A mobile-friendly, chat-styled wrapper around a **real** `freebuff` terminal
session. Nothing is simulated: the backend spawns the actual `freebuff`
CLI inside a pseudo-terminal (`node-pty`), streams every byte of its
output to the browser over a websocket, and sends every keystroke you
type straight to its stdin. The frontend renders it with `xterm.js`, so
colors, cursor movement, and interactive prompts work exactly as they
would in a real terminal — just skinned to feel like a chat.

## How it works

- **`server/index.js`** — Node/Express server. On each websocket
  connection it spawns `freebuff` in a pty (`node-pty`) and relays raw
  bytes both directions. It also passively scans the output stream for
  login/device-code prompts (URL + code patterns) so the frontend can
  show a distinct "Login" overlay — but it never alters, mocks, or
  rewrites the actual bytes sent to the terminal.
- **`public/app.js` + `index.html` + `style.css`** — `xterm.js` terminal
  wrapped in a chat-like shell (header, rounded terminal panel, bottom
  composer). The composer sends what you type as real stdin
  (`text + "\r"`); the terminal itself also forwards raw keystrokes, so
  control sequences (Ctrl+C, arrow keys inside CLI menus, etc.) still work
  if you tap into the terminal directly.

## Security

This app spawns a real, interactive shell-like process and gives whoever
is connected full read/write access to it. Treat it like SSH access, not
like a static webpage.

- **Auth token required.** The server refuses to start unless `AUTH_TOKEN`
  is set, and every WebSocket connection must include `?token=<value>`
  matching it (checked with a constant-time comparison). Set this as a
  Replit Secret, not a plaintext value in `.replit`.
- **Origin allowlist.** Cross-origin WebSocket upgrades are rejected by
  default (same-origin only). Set `ALLOWED_ORIGINS` (comma-separated) if
  you need to allow a specific other origin.
- **Environment allowlist.** The spawned `freebuff` process only receives
  a small allowlist of environment variables (PATH, HOME, TERM, etc.), not
  your full server environment. Add extra variables the CLI needs by
  prefixing them `FREEBUFF_ENV_YOURVAR=value`, which the server passes
  through as `YOURVAR`.
- **Connection & input limits.** `MAX_CONNECTIONS` caps concurrent
  sessions (default 5), `IDLE_TIMEOUT_MS` auto-closes idle sessions
  (default 30 min), and individual stdin messages are capped at 8KB and
  type-checked before being written to the pty.

Generate a strong token before deploying:

```bash
node -e "console.log(require('crypto').randomBytes(24).toString('hex'))"
```

## Setup

You need Node.js 18+ and a working native build toolchain (`node-pty`
compiles a native addon).

```bash
cd freebuff-chat
npm install
```

This repo does not ship a `package-lock.json` — generate one on first
install in your actual target environment (`npm install` creates it) and
commit it, then use `npm ci` for subsequent/deployment installs so
versions stay reproducible. Dependency versions in `package.json` are
pinned exactly (no `^` ranges) to reduce drift in the meantime.

If `npm install` fails while building `node-pty`, install build
essentials first:

```bash
# Debian/Ubuntu
sudo apt-get install -y build-essential python3

# macOS
xcode-select --install
```

Install the real CLI (if you haven't already):

```bash
npm install -g freebuff
```

## Run

```bash
export AUTH_TOKEN=$(node -e "console.log(require('crypto').randomBytes(24).toString('hex'))")
echo "Your token: $AUTH_TOKEN"
npm start
```

Then open **http://localhost:8787/?token=YOUR_TOKEN_HERE** (the token is
cached in `sessionStorage` after first load and stripped from the visible
URL, so you won't need to paste it again in that tab). On mobile, use
your machine's LAN IP instead of localhost, e.g.
`http://192.168.1.23:8787/?token=...`

**Note on the token:** it's passed as a URL query parameter, which is
simple to set up but can end up in browser history, reverse-proxy access
logs, or dev-tools network panels. That's an acceptable tradeoff for
personal/low-stakes use but not a hardened design — if you need something
stronger, swap this for a short-lived one-time link that exchanges for an
`HttpOnly`/`Secure`/`SameSite` cookie instead.

On load, the server immediately spawns `freebuff`. Whatever it prints —
including its real login/device-code flow — streams straight into the
terminal. If the server detects a login/auth prompt in that output, it
also surfaces a "Login" overlay with any link/code it found, pulled
verbatim from the real CLI text. The overlay is just a convenience; the
raw terminal underneath is still live the whole time, and you can
dismiss the overlay once you've completed sign-in in your browser.

## Configuration

Environment variables (set before `npm start`, or in a `.env`/shell
export):

| Variable | Purpose | Default |
|---|---|---|
| `PORT` | HTTP/WS port | `8787` |
| `FREEBUFF_CMD` | Command to spawn | `freebuff` |
| `FREEBUFF_ARGS` | JSON array of string args, e.g. `["--flag","value with spaces"]` | *(none)* |
| `FREEBUFF_CWD` | Working directory the CLI runs in | your home dir |
| `AUTH_TOKEN` | Required. Shared secret clients must pass as `?token=` | *(none — server won't start)* |
| `ALLOWED_ORIGINS` | Comma-separated list of allowed Origins for cross-origin WS | same-origin only |
| `MAX_CONNECTIONS` | Max concurrent sessions | `5` |
| `IDLE_TIMEOUT_MS` | Auto-close idle sessions after this many ms | `1800000` (30 min) |
| `FREEBUFF_ENV_*` | Pass an extra env var to the spawned CLI, e.g. `FREEBUFF_ENV_FOO=bar` → child sees `FOO=bar` | *(none)* |

Example — run against a specific project directory with a custom arg:

```bash
FREEBUFF_CWD=~/my-project FREEBUFF_ARGS='["--verbose"]' npm start
```

If `freebuff` isn't on `PATH` (e.g. installed via a version manager),
point directly at it:

```bash
FREEBUFF_CMD=/full/path/to/freebuff npm start
```

## Notes / limitations

- **One freebuff process per browser tab connection.** Closing the tab
  or losing the websocket kills that pty process. Reloading starts a
  fresh session (and a fresh login, if freebuff doesn't persist
  credentials between runs in your environment — by default it stores
  a device-auth token locally, so most of the time you won't be asked
  to log in again).
- **Login detection is heuristic.** The server looks for common
  phrasing ("sign in", "device code", a URL, an uppercase code pattern)
  to decide when to pop the login overlay. It's a UI convenience layered
  on top of the real stream — the actual terminal output is always
  visible and authoritative regardless of whether detection fires.
- Freebuff is ad-supported and may analyze what you type (including
  pasted content) to personalize ads, per its own privacy policy —
  this wrapper doesn't change that; it's a direct pass-through to the
  real CLI.
